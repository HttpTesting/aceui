# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['aceui', 'aceui.base', 'aceui.lib']

package_data = \
{'': ['*'],
 'aceui': ['.git/*',
           '.git/hooks/*',
           '.git/info/*',
           '.git/logs/*',
           '.git/logs/refs/heads/*',
           '.git/logs/refs/remotes/github/*',
           '.git/objects/03/*',
           '.git/objects/04/*',
           '.git/objects/16/*',
           '.git/objects/1c/*',
           '.git/objects/1f/*',
           '.git/objects/25/*',
           '.git/objects/27/*',
           '.git/objects/2f/*',
           '.git/objects/41/*',
           '.git/objects/48/*',
           '.git/objects/4b/*',
           '.git/objects/5d/*',
           '.git/objects/60/*',
           '.git/objects/70/*',
           '.git/objects/72/*',
           '.git/objects/7c/*',
           '.git/objects/91/*',
           '.git/objects/99/*',
           '.git/objects/9f/*',
           '.git/objects/a5/*',
           '.git/objects/b1/*',
           '.git/objects/ba/*',
           '.git/objects/bc/*',
           '.git/objects/be/*',
           '.git/objects/bf/*',
           '.git/objects/d0/*',
           '.git/objects/d4/*',
           '.git/objects/d5/*',
           '.git/objects/db/*',
           '.git/objects/e6/*',
           '.git/objects/f0/*',
           '.git/objects/f7/*',
           '.git/objects/fc/*',
           '.git/objects/fe/*',
           '.git/refs/heads/*',
           '.git/refs/remotes/github/*',
           'config/*',
           'whls/*']}

install_requires = \
['Pillow==5.3.0',
 'PyAutoIt==0.4',
 'PyYAML==5.1.1',
 'ddt==1.1.3',
 'requests==2.25.0',
 'selenium==3.141.0']

entry_points = \
{'console_scripts': ['ace = aceui.main:run_min', 'aceui = aceui.main:run_min']}

setup_kwargs = {
    'name': 'aceui',
    'version': '1.0.1',
    'description': '基于Selenium的UI自动化测试框架',
    'long_description': '\ufeff# AceUI\n[![Build Status](https://travis-ci.org/HttpTesting/pyhttp.svg?branch=master)](https://travis-ci.org/HttpTesting/aceui)\n![PyPI](https://img.shields.io/pypi/v/aceui)\n![PyPI - License](https://img.shields.io/pypi/l/aceui)\n![PyPI - Python Version](https://img.shields.io/pypi/pyversions/aceui)\n![PyPI - Wheel](https://img.shields.io/pypi/wheel/aceui)\n\n\nAceUI是基于Selenium的UI自动化测试框架。\n\n\n\n\n## 功能描述\nAceUI是基于Selenium的UI自动化测试框架\n\n\n  \n### 通过poetry工具打包\n\n- poetry build\n\n- poetry config repositories.testpypi https://pypi.org/project/aceui\n\n- poetry publish  输入pypi用户名和密码',
    'author': '天枢',
    'author_email': 'lengyaohui@163.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': 'https://github.com/HttpTesting/aceui',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
}


setup(**setup_kwargs)
