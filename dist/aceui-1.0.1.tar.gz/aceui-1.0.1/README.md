﻿# AceUI
[![Build Status](https://travis-ci.org/HttpTesting/pyhttp.svg?branch=master)](https://travis-ci.org/HttpTesting/aceui)
![PyPI](https://img.shields.io/pypi/v/aceui)
![PyPI - License](https://img.shields.io/pypi/l/aceui)
![PyPI - Python Version](https://img.shields.io/pypi/pyversions/aceui)
![PyPI - Wheel](https://img.shields.io/pypi/wheel/aceui)


AceUI是基于Selenium的UI自动化测试框架。




## 功能描述
AceUI是基于Selenium的UI自动化测试框架


  
### 通过poetry工具打包

- poetry build

- poetry config repositories.testpypi https://pypi.org/project/aceui

- poetry publish  输入pypi用户名和密码