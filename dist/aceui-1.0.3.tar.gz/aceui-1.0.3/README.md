﻿# AceUI

AceUI是基于Selenium的UI自动化测试框架。






  
### 通过poetry工具打包

- poetry build

- poetry config repositories.testpypi https://pypi.org/project/aceui

- poetry publish  输入pypi用户名和密码